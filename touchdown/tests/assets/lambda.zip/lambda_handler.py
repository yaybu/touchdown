def handler(*args):
    pass
